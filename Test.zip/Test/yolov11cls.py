from ultralytics import YOLO
from IPython.display import display, Image

# Load the YOLO classification model
model = YOLO("BaselineModel.pt")  # Pretrained classification model

# Load an image for classification
image_path = "Seen10.jpg"  # Replace with your image path

# Perform classification
results = model.predict(source=image_path)
results[0].show()
